# PocketLedger — React + Vite + TypeScript + SQLite

An original expense-manager app inspired by common personal finance workflows. It uses React/Vite for the UI, SQLite WASM persisted locally in the browser, and native SQLite through Capacitor on Android. It has no login, backend, or cloud sync.

## Features
- Monthly income, expense, and balance summary
- Create, edit, delete, search, and filter transactions
- Categories, payment method, date, and notes
- Monthly budget with progress indicator
- Category breakdown and CSV export
- Responsive interface
- Local-first offline storage: browser SQLite WASM + localStorage; Android native SQLite

## Requirements
Install Node.js LTS from https://nodejs.org/ and VS Code. For Android builds install Android Studio and its Android SDK.

Check Node:
```powershell
node --version
npm --version
```

## Run in VS Code
1. Extract the ZIP.
2. VS Code → File → Open Folder → select `expense_manager_react_capacitor` (the folder containing package.json).
3. Terminal → New Terminal.
4. Run each command separately:
```powershell
npm install
npm run dev
```
Open the localhost URL Vite prints, usually `http://localhost:5173`.

## Test and build web
```powershell
npm test
npm run build
npm run preview
```
The deployable static files are in `dist/`.

## Android setup
After `npm install`, add Android once:
```powershell
npx cap add android
```
If `android/` already exists, do not add it again. Then:
```powershell
npm run build
npx cap sync android
npx cap open android
```
Android Studio opens the native project. Wait for Gradle sync, install requested SDKs, start an emulator or connect an Android phone with USB debugging, and press Run. For an APK, use Android Studio → Build → Build Bundle(s) / APK(s) → Build APK(s).

## Database
See `docs/DATABASE.md`. Web uses sql.js (SQLite compiled to WASM), exports the database to localStorage after each write. Android uses @capacitor-community/sqlite and a device-local SQLite database. Data is not synchronized across web and Android. Browser data is tied to the exact site origin; clearing site data may erase it. Export CSV backups.

## Deploy web
Run `npm run build`, then deploy the contents of `dist/` to a static host such as Netlify, Cloudflare Pages, or GitHub Pages. Use HTTPS and confirm `sql-wasm.wasm` is included and served correctly. First visit requires loading app assets; offline repeat visits depend on browser cache/hosting configuration.

## Troubleshooting
- `npm` not recognized: install Node.js LTS, close/reopen VS Code, retry `node --version` and `npm --version`.
- SQLite WASM missing: run `node scripts/copy-wasm.mjs`.
- Android build errors: open Android Studio, wait for Gradle sync, install requested SDK/JDK tools, then `npx cap sync android`.
- Different data on web and Android is expected; there is no cloud sync.

## Limitations
The browser stores a serialized SQLite database in localStorage, which has storage quotas and is suitable for a student/personal project rather than high-volume data. Google Fonts are optional; the UI falls back to sans-serif. No bank connections, payments, cloud backups, or user accounts.

This source package has not been built or tested in an actual Node/Android toolchain here. Run `npm install`, `npm test`, and `npm run build` locally before submitting.
