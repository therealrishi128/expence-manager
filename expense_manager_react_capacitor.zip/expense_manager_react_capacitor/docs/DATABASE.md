# Database schema

`transactions`: `id INTEGER PRIMARY KEY AUTOINCREMENT`, `title TEXT NOT NULL`, `amount INTEGER NOT NULL` (paise), `type TEXT` (`expense`/`income`), `category TEXT`, `method TEXT`, `note TEXT`, `date TEXT` (`YYYY-MM-DD`).

`settings`: `key TEXT PRIMARY KEY`, `value TEXT NOT NULL`; `budget` stores the monthly budget in paise.

Web: SQLite WASM serialized to localStorage key `pocketledger.sqlite.v1`. Android: native SQLite database named `pocketledger`. Money is stored as integer paise to avoid floating point storage errors.
