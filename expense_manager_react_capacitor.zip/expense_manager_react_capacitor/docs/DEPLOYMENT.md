# Deployment

## Web
1. `npm install`
2. `npm run build`
3. Deploy `dist/` to Netlify, Cloudflare Pages, or GitHub Pages.
4. Ensure `sql-wasm.wasm` is in `dist/` and served with a WebAssembly-compatible MIME type.
5. Test on the production origin; browser storage is tied to hostname and port.

## Android
1. `npx cap add android` (once)
2. `npm run build`
3. `npx cap sync android`
4. `npx cap open android`
5. Test on emulator/device. Use Android Studio's Build APK or Generate Signed Bundle/APK workflow for release.

No server or account is used; records remain local to each platform.
